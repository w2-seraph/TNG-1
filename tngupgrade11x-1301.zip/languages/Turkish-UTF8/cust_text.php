<?php
//Mods should put their changes before this line, local changes should come after it.
//Put your own custom messages here, like this:
//$text['messagename'] = "This is the message";
?>
