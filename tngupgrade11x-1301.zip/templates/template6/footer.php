<!-- begin footer -->
<?php global $text, $flags, $tng_version; ?>
		</td>
	</tr>
	
	<tr>
		<td colspan="4" class="gradientup">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="4" class="headerback">
		    <div class="footer">
			<?php
				$flags['basicfooter'] = true;
				echo tng_footer($flags);
			?>
			</div>
		</td>
	</tr>
</table>

<!-- end footer for template 6 -->