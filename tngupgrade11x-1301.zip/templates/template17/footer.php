<?php global $text, $currentuser, $mylanguage, $cms, $tmp, $tng_version, $flags; ?>
	<br/>
</div>
<div id="subfooter">
<?php
	$flags['basicfooter'] = true;
	echo tng_footer($flags);
?>
</div>
<!-- end of footer.php for template 1 -->