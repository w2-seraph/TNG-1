<?php global $text, $currentuser, $mylanguage, $cms, $tmp, $tng_version, $flags; ?>

				</div>
			</div>
			<hr size="1" />
<?php
	$flags['basicfooter'] = true;
	echo tng_footer($flags);
?>
			<br />
		</div>
	</div>
</div>
<!-- end of footer.php for template 1 -->