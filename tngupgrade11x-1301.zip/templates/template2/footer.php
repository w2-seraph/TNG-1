<?php global $text, $flags, $currentuser, $mylanguage, $cms, $tngconfig, $tng_version; ?>
<!-- begin footer.php -->
						</div>
					</td>
				</tr>
			</table>
	
	</td></tr>


	<tr><td colspan="4" class="tablebottomedge"></td></tr>
	<tr>
		<td colspan="4" >
	<div class="footer">
		<br/>
<?php
	$flags['basicfooter'] = true;
	echo tng_footer($flags);
?>
		<br />
	</div>
		</td>
	</tr>
</table>
<!-- end footer.php for template 2 -->