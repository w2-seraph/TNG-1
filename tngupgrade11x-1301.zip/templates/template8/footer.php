<!-- begin footer -->
<?php global $text, $flags, $tng_version; ?>
	</td></tr>
	<tr>
	    <td colspan="2" class="footer">
			<?php
				$flags['basicfooter'] = true;
				echo tng_footer($flags);
			?>
	    </td>
	</tr>
</table>
<!-- end footer -->